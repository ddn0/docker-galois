/*
 * AVIorderedSerial.cpp
 *
 *  Created on: Jun 21, 2011
 *      Author: amber
 */
#include "AVIabstractMain.h"

int main (int argc, char* argv[]) {
  AVIorderedSerial serial;
  serial.run (argc, argv);
  return 0;
}

