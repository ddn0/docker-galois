/*
 * AVIodgExplicitNoLock.cpp
 *
 *  Created on: Jun 21, 2011
 *      Author: amber
 */

#include "AVIodgExplicitNoLock.h"

int main (int argc, char* argv[]) {
  AVIodgExplicitNoLock um;
  um.run (argc, argv);
  return 0;
}

