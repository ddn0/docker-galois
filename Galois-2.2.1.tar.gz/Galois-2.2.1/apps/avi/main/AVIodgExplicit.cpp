/*
 * AVIodgExplicit.cpp
 *
 *  Created on: Jun 21, 2011
 *      Author: amber
 */

#include "AVIodgExplicit.h"

int main (int argc, char* argv[]) {
  AVIodgExplicit um;
  um.run (argc, argv);
  return 0;
}

