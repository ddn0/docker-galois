#include "NetlistParser.h"

const char* des::NetlistParser::DELIM = " \n\t,;()=";
const char* des::NetlistParser::COMMENTS = "//";
