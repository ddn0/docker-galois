#include "Galois/Runtime/ll/HWTopo.h"

__thread unsigned Galois::Runtime::LL::PACKAGE_ID = 0;
