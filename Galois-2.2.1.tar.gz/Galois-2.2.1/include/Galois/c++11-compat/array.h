#ifndef GALOIS_C__11_COMPAT_ARRAY_H
#define GALOIS_C__11_COMPAT_ARRAY_H

#include <boost/tr1/array.hpp>
namespace std { using namespace std::tr1; }

#endif

