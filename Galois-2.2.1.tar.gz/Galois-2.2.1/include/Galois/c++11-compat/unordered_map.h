#ifndef GALOIS_C__11_COMPAT_UNORDERED_MAP_H
#define GALOIS_C__11_COMPAT_UNORDERED_MAP_H

#include <boost/tr1/unordered_map.hpp>
namespace std { using namespace std::tr1; }
#endif
