#ifndef GALOIS_C__11_COMPAT_TUPLE_H
#define GALOIS_C__11_COMPAT_TUPLE_H

#include <boost/tr1/tuple.hpp>
namespace std { using namespace std::tr1; }

#endif

