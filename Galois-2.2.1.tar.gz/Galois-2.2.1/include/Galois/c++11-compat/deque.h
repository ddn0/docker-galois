#ifndef GALOIS_C__11_COMPAT_DEQUE_H
#define GALOIS_C__11_COMPAT_DEQUE_H

#include <deque>
#define GALOIS_CXX11_DEQUE_HAS_NO_EMPLACE

#endif
