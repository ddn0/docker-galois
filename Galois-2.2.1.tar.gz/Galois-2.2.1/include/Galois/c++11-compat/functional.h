#ifndef GALOIS_C__11_COMPAT_FUNCTIONAL_H
#define GALOIS_C__11_COMPAT_FUNCTIONAL_H
#include <functional>
#include <boost/tr1/functional.hpp>
namespace std { using namespace std::tr1; }
#endif
