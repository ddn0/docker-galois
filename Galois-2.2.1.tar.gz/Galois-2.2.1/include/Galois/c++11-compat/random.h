#ifndef GALOIS_C__11_COMPAT_RANDOM_H
#define GALOIS_C__11_COMPAT_RANDOM_H

#include <boost/tr1/random.hpp>
namespace std { using namespace std::tr1; }

#endif
