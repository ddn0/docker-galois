#ifndef GALOIS_C__11_COMPAT_UNORDERED_SET_H
#define GALOIS_C__11_COMPAT_UNORDERED_SET_H

#include <boost/tr1/unordered_set.hpp>
namespace std { using namespace std::tr1; }
#endif
