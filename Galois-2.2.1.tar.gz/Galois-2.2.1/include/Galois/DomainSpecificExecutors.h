#ifndef GALOIS_DOMAINSPECIFICEXECUTORS_H
#define GALOIS_DOMAINSPECIFICEXECUTORS_H

#include "LigraExecutor.h"
#include "GraphChiExecutor.h"
#include "GraphLabExecutor.h"
#include "LigraGraphChiExecutor.h"

#endif
